const Icon_vue_vue_type_style_index_0_scoped_f43f2976_lang = ".icon[data-v-f43f2976]{display:inline-block;vertical-align:middle}";

const IconStyles_6b624e4d = [Icon_vue_vue_type_style_index_0_scoped_f43f2976_lang];

export { IconStyles_6b624e4d as default };
//# sourceMappingURL=Icon-styles.6b624e4d.mjs.map
