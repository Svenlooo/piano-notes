import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'h3';
import 'devalue';
import 'vue/server-renderer';
import '../../nitro/netlify.mjs';
import 'node-fetch-native/polyfill';
import 'ufo';
import 'defu';
import 'radix3';
import 'destr';
import 'scule';
import 'klona';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'ohash';
import 'unstorage';

const Accidental_vue_vue_type_style_index_0_scoped_9a2b5844_lang = '@font-face{font-family:GreatVibes;font-weight:400;src:local("GreatVibes"),url(' + buildAssetsURL("GreatVibes-Regular.efeda7b9.woff2") + ') format("woff2"),url(' + buildAssetsURL("GreatVibes-Regular.39371d05.ttf") + ') format("truetype")}.icon[data-v-9a2b5844]{height:auto;width:36px}';

const AccidentalStyles_8d2492b3 = [Accidental_vue_vue_type_style_index_0_scoped_9a2b5844_lang];

export { AccidentalStyles_8d2492b3 as default };
//# sourceMappingURL=Accidental-styles.8d2492b3.mjs.map
