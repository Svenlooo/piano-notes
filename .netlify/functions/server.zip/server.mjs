globalThis._importMeta_={url:import.meta.url,env:process.env};import 'node-fetch-native/polyfill';
import 'ufo';
export { h as handler } from './chunks/nitro/netlify.mjs';
import 'h3';
import 'defu';
import 'radix3';
import 'destr';
import 'scule';
import 'klona';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'ohash';
import 'unstorage';
//# sourceMappingURL=server.mjs.map
